require_relative './galaxy_unit'
require_relative './metal_unit'

class Parser
  attr_reader :galaxy_unit, :metal_unit

  def initialize(galaxy_unit:, metal_unit:)
    @galaxy_unit = galaxy_unit
    @metal_unit = metal_unit
  end

  def process_line(line)
    case line
    when  /^([a-z]*) is (I|V|X|L|C|D|M)$/
      @galaxy_unit.add(name: $1, roman_unit: $2)
    when  /^([a-z ]+) ([A-Z][a-z]+) is (\d+) Credits$/
      @metal_unit.add(galaxy_units: $1.split, name: $2, credits: $3)
    when /^how much is ([a-z ]+) \?$/
      galaxy_units_value = @galaxy_unit.convert_to_arabic($1.split)
      puts "#{$1} is #{galaxy_units_value} Credits"
    when  /^how many Credits is ([a-z ]+) ([A-Z][a-z]+) \?/
      metal_unit_value = @metal_unit.convert_to_credits(galaxy_units: $1.split, name: $2)
      puts "#{$1} #{$2} is #{metal_unit_value} Credits"
    else
      puts "I have no ideas what you're talking about"
    end
  end
end
