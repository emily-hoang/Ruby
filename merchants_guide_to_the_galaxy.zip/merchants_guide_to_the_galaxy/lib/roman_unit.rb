class RomanUnit
  VALID_ROMAN_UNIT = /^(?:M{0,3}(?:CM|CD|D?C{0,3})(?:XC|XL|L?X{0,3})(?:IX|IV|V?I{0,3}))$/i
  ROMAN_MAPPING = {
    "M" => 1000,
    "CM" => 900,
    "D" => 500,
    "CD" => 400,
    "C" => 100,
    "XC" => 90,
    "L" => 50,
    "XL" => 40,
    "X" => 10,
    "IX" => 9,
    "V" => 5,
    "IV" => 4,
    "I" => 1
  }

  def initialize(roman_unit)
    raise UnknownRomanUnit unless VALID_ROMAN_UNIT.match?(roman_unit)

    @roman_unit = roman_unit.upcase
  end

  def to_arabic                           
    roman_unit = @roman_unit
    number = 0

    ROMAN_MAPPING.each do |k, v|                    
      while roman_unit.start_with?(k)
        roman_unit = roman_unit.slice(k.length, roman_unit.length)
        number += v
      end
    end
    return number
  end
end

class UnknownRomanUnit < RuntimeError; end

