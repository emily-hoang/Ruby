require_relative 'roman_unit'

class GalaxyUnit
  attr_reader :galaxy_units

  def initialize
    @galaxy_units = {}
  end

  def add(name:, roman_unit:)
    @galaxy_units[name] = roman_unit
  end

  def convert_to_arabic(names)
    values = []

    if (names - @galaxy_units.keys).length.zero?
      values = names.map do |name|
        @galaxy_units[name]
      end

      to_arabic(values.join(''))
    else
      return false
    end
  end

  def get_value_for(name)
    @galaxy_units[name]
  end

  private

  def to_arabic(roman_unit)
    RomanUnit.new(roman_unit).to_arabic
  end
end
