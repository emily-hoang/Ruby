require_relative './galaxy_unit'

class MetalUnit
  def initialize(galaxy_unit)
    @galaxy_unit = galaxy_unit
    @metals = {}
  end

  def add(galaxy_units:, name:, credits:)
    return false if @galaxy_unit.convert_to_arabic(galaxy_units) == false
      @metals[name] = credits.to_f / @galaxy_unit.convert_to_arabic(galaxy_units)
  end

  def convert_to_credits(galaxy_units:, name:)
    return false if @metals[name].nil?
      (@galaxy_unit.convert_to_arabic(galaxy_units) * get_value_for(name)).to_i
  end

  def get_value_for(name)
    @metals[name]
  end
end
