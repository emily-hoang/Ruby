require 'spec_helper'

RSpec.describe RomanUnit do
  it 'will be a RomanUnit' do
    expect(RomanUnit.new("MMII")).to be_a(RomanUnit)
  end

  describe "#initialize" do
    let(:roman_unit) { RomanUnit.new(roman_numeral) }

    context "when the roman unit input is valid" do
      let(:roman_numeral) { "MMCI" }

      it "will return a new RomanUnit" do
        expect(roman_unit).to be_a(RomanUnit)
      end
    end

    context "when the roman unit is invalid" do
      let(:roman_numeral) { "abc" }

      it "will raise an error for an UnknownRomanUnit" do
        expect{ roman_unit }.to raise_error(UnknownRomanUnit)
      end
    end
  end

  describe "#to_arabic" do 
    context "convert the roman unit to numbers" do
      let(:test_cases) do 
        {
          "I" => 1,
          "II" => 2,
          "III" => 3,
          "IV" => 4,
          'V' => 5, 
          "VI" => 6,
          "VII" => 7,
          "VIII" => 8,
          "IX" => 9,
          "X" => 10,
          "XIII" => 13,
          "XV" => 15,
          "XVIII" => 18,
          "XIX" => 19,
          "XXX" => 30,
          "XL" => 40,
          "XLII" => 42,
          "L" => 50,
          "LI" => 51,
          "LXXXIX" => 89,
          "XCIX" => 99,
          "CXLV" => 145,
          "CDLIX" => 459,
          "MCMLXXXIV" => 1984,
          "MDXLV" => 1545,
          "MMMCMXXXVI" => 3936
        }
      end

      it "will convert roman unit to number" do
        test_cases.each do |roman_unit, value|
          expect(RomanUnit.new(roman_unit).to_arabic).to eq(value), "#{roman_unit} should equal #{value}"
        end
      end
    end
  end
end
