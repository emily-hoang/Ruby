require_relative 'spec_helper'

RSpec.describe MetalUnit do
  describe "#initialize" do
    let(:galaxy_unit) { GalaxyUnit.new }

    it "will be a MetalUnit" do
      expect(MetalUnit.new(galaxy_unit)).to be_a(MetalUnit)
    end
  end

  describe "#add" do
    let(:metal_unit) { MetalUnit.new(galaxy_unit) }
    let(:galaxy_unit) { GalaxyUnit.new }

    context "when the parameters are valid" do
      it "will add a metal value" do
        galaxy_unit.add(name: "glob", roman_unit: "I")
        set_metal_unit = metal_unit.add(galaxy_units: ["glob", "glob"], name: "silver", credits: 34)

        expect(set_metal_unit).to eq(17)
      end
    end

    context 'when attempting to add the metal but the galaxy unit is not exists' do
      it 'will return false' do
        galaxy_unit.add(name: "glob", roman_unit: "I")
        set_metal_unit = metal_unit.add(galaxy_units: ['mark'], name: "silver", credits: 34)

        expect(set_metal_unit).to eq(false)
      end
    end
  end

  describe "#convert_to_credits" do
    let(:metal_unit) { MetalUnit.new(galaxy_unit) }
    let(:galaxy_unit) { GalaxyUnit.new }

    let(:galaxy_units) { ["glob", "glob"] }
    let(:metal_name) { 'Silver' }
    let(:metal_name_for_conversion) { metal_name }

    let(:metal_unit_conversion) { metal_unit.convert_to_credits(galaxy_units: galaxy_units, name: metal_name_for_conversion) }

    before do
      galaxy_unit.add(name: "glob", roman_unit: "I")
      metal_unit.add(galaxy_units: galaxy_units, name: metal_name, credits: 34)
    end

    context 'when the metal unit is set' do
      it "will return the value of the metal unit" do
        expect(metal_unit_conversion).to eq(34)
      end
    end

    context 'when the metal name isnt known' do
      let(:metal_name_for_conversion) { 'anUnknownName' }
      it 'will return false' do
        expect(metal_unit_conversion).to eq(false)
      end
    end
  end
end