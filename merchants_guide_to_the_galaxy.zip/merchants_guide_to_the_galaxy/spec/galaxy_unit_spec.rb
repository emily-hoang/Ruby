require 'spec_helper'

RSpec.describe GalaxyUnit do
  it "will be a GalaxyUnit" do
    expect(GalaxyUnit.new).to be_a(GalaxyUnit)
  end

  describe "#add" do
    let(:galaxy_unit) { GalaxyUnit.new }

    context "when the galaxy unit is set" do
      it "will return the arabic value of a galaxy unit" do
        galaxy_unit.add(name: "glob", roman_unit: 'I')
        
        expect(galaxy_unit.get_value_for("glob")).to eq("I")
      end
    end

    context "when the galaxy unit is missing the parameters" do
      it "will return false" do
        expect { galaxy_unit.get_value_for }.to raise_error(ArgumentError)
      end
    end
  end

  describe "#convert_to_arabic" do
    let(:galaxy_unit) { GalaxyUnit.new }

    context "when the string passed in is valid" do
      it "will sum the galaxy unit values" do
        galaxy_unit.add(name: "glob", roman_unit: "I")
        galaxy_unit.add(name: "pish", roman_unit: "X")
        galaxy_unit.add(name: "tegj", roman_unit: "L")

        galaxy_unit.convert_to_arabic(["pish", "tegj", "glob", "glob"])
        
        expect(galaxy_unit.convert_to_arabic(["pish", "tegj", "glob", "glob"])).to eq(42)
      end
    end

    context "when the string passed in is invalid" do
      it "will raise an exception" do
        galaxy_unit.add(name: "glob", roman_unit: "I")
        galaxy_unit.add(name: "pish", roman_unit: "V")
        
        expect(galaxy_unit.convert_to_arabic(["chuck", "pish"])).to eq(false)
      end
    end
  end

  describe "#get_value_for" do
    let(:galaxy_unit) { GalaxyUnit.new }

    it "will get the value of the galaxy unit" do
      galaxy_unit.add(name: "glob", roman_unit: "I")
      
      expect(galaxy_unit.get_value_for("glob")).to eq("I")
    end
  end
end
