require 'spec_helper'

RSpec.describe Parser do
  let(:parser) { Parser.new(galaxy_unit: galaxy_unit, metal_unit: metal_unit) }
  let(:galaxy_unit) { GalaxyUnit.new }
  let(:metal_unit) { MetalUnit.new(galaxy_unit) }

  describe "#initialize" do
    it "will be a Parser" do
      expect(parser).to be_a(Parser)
    end
  end

  describe "#process_line" do
    context "when adding a galaxy unit" do
      it "will add a galaxy unit" do
        galaxy_unit.add(name: "glob", roman_unit: "I")
        line = "glob is I"

        expect{ parser.process_line(line) }.to output("").to_stdout
      end
    end

    context "when adding a metal unit" do
      it "will add a metal unit" do
        galaxy_unit.add(name: "glob", roman_unit: "I")
        metal_unit.add(galaxy_units: ["glob", "glob"], name: "Silver", credits: 34)
        line = "glob glob Silver is 34 Credits"

        expect{ parser.process_line(line) }.to output("").to_stdout
      end
    end

    context "how much is galaxy units ?" do
      it "will return a message of the galaxy unit names and the total value" do
        galaxy_unit.add(name: "glob", roman_unit: "X")
        galaxy_unit.add(name: "pish", roman_unit: "L")
        galaxy_unit.add(name: "tegj", roman_unit: "I")
        galaxy_unit.convert_to_arabic(["glob", "pish", "tegj"])
        line = "how much is glob pish tegj ?"

        expect { parser.process_line(line) }.to output("glob pish tegj is 41 Credits\n").to_stdout
      end
    end

    context "how many Credits is n * metals ?" do
      it "will return a message of the metal unit name and its value" do
        galaxy_unit.add(name: "glob", roman_unit: "I")
        metal_unit.add(galaxy_units: ["glob", "glob"], name: "Silver", credits: 40)
        metal_unit.convert_to_credits(galaxy_units: ["glob", "glob"], name: "Silver")
        line = "how many Credits is glob glob Silver ?"

        expect { parser.process_line(line) }.to output("glob glob Silver is 40 Credits\n").to_stdout
      end
    end
  end

end