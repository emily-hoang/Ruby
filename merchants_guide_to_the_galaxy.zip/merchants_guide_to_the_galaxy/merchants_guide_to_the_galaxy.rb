require_relative './lib/galaxy_unit'
require_relative './lib/metal_unit'
require_relative './lib/parser'

galaxy_unit = GalaxyUnit.new
metal_unit = MetalUnit.new(galaxy_unit)
parser = Parser.new(galaxy_unit: galaxy_unit, metal_unit: metal_unit)

if ARGV.length.possitive?
  input = ARGV[0]

  if File.exist?(input)
    File.open(input).each_line do |line|
      parser.read_line(line)
    end
  else
    puts "The input file doesn't exist"
  end
else
  puts "Usage: ruby merchants_guide_to_the_galaxy.rb input.txt"
end


